#ifndef MYFIRST_HPP
#define MYFIRST_HPP

// declaration of template
template <typename T>
void printTypeof(T const&);

#endif  // MYFIRST_HPP
