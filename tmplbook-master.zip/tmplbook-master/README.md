# C++ Templates - The Complete Guide, 2nd Edition

These are the examples from the following book:

 Nicolai M. Josuttis  
 C++ Templates - The Complete Guide, 2nd Edition  
 Addison-Wesley, 2017  
 ISBN-13:  978-0-321-71412-1  
 ISBN-10:  0-321-71412-1  

**Copyright © 2017 by Addison-Wesley, David Vandevoorde, Nicolai M. Josuttis, and Douglas Gregor.**

These examples are covered under the copyright and warranty notices printed in that book. However, the publisher grants permission, without fee, for the code to be copied and used for personal and educational purposes, provided that the citation above, including the copyright notice, appears with each copy made.

Note that any commercial use of this code requires the explicit written permission of the publisher. To obtain permission, please submit a written request to Pearson Education, Inc., Permissions Department, One Lake Street, Upper Saddle River, New Jersey 07458, USA, or you may fax your request to +1-201-236-3290.

For further informations see: http://www.tmplbook.com
